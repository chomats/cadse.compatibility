package fede.workspace.domain.root.type;


/**
	@generated
*/
public enum TWEvol  {
	
	twFinal,
	twTransient,
	twMutable,
	twImmutable,
}
