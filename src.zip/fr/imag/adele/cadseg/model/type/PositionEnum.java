package fr.imag.adele.cadseg.model.type;



/**
 * The Enum PositionEnum.
 * 
 * @generated
 */
public enum PositionEnum  {
	
	/** The left. */
	left,
	
	/** The top. */
	top,
	
	/** The right. */
	right,
	
	/** The group. */
	group,
	
	/** The none. */
	none,
	
	/** The defaultpos. */
	defaultpos,
}
